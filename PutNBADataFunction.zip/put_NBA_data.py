import json
import requests
import boto3

dynamodb = boto3.client('dynamodb')

TABLE_NAME = 'NBA-dataset'


def lambda_handler(event, context):
    dataDict = {}
    try:
        r = requests.get('https://www.balldontlie.io/api/v1/games?start_date=2020-03-01&per_page=100').json()
        for item in r['data']:
            dataDict['id'] = {'N': str(item['id'])}
            dataDict['date'] = {'S': item['date']}
            dataDict['home_team_score'] = {'N': str(item['home_team_score'])}
            dataDict['visitor_team_score'] = {'N': str(item['visitor_team_score'])}
            dataDict['home_team'] = {'S': item['home_team']['full_name']}
            dataDict['visitor_team'] = {'S': item['visitor_team']['full_name']}


            response = dynamodb.put_item(
                TableName=TABLE_NAME,
                Item=dataDict
            )
    except Exception as e:
        print(e)

    return {
        'statusCode': 200,
        'body': json.dumps('Insert Complete!')
    }
